#ifndef IMAGE_HPP
#define IMAGE_HPP
#include <opencv2/core.hpp>
#include <opencv2/features2d.hpp>
#include <vector>

class Image
{
	private:
		cv::Mat pixels;
		std::vector<cv::KeyPoint> keypoints;
		cv::Mat descriptors;
		std::string name;
	public:
		Image(cv::Mat pixels, std::string name);
		cv::Mat* get_pixels();
		std::vector<cv::KeyPoint>* get_keypoints();
		cv::Mat* get_descriptors();
		std::string get_name();
		bool get_is_a_centroid();
		void set_is_a_centroid(bool is_a_centroid);
};
#endif // IMAGE_HPP
#ifndef K_MEANS_CLUSTERER_HPP
#define K_MEANS_CLUSTERER_HPP
#include <iostream>
#include "Cluster.hpp"

class K_Means_Clusterer
{
	private:
		void generate_clusters(std::vector<Cluster>* clusters,
			                   std::vector<Image>* images,
			                   int num_clusters);
	public:
		K_Means_Clusterer();
		void cluster_by_SIFT_features(std::vector<Cluster>* clusters,
			                          std::vector<Image>* images,
			                          int num_clusters, 
			                          int num_epochs, 
			                          int cluster_size_limit,
			                          int max_penalties, 
			                          int timeout_duration);
};
#endif // K_MEANS_CLUSTERER_HPP
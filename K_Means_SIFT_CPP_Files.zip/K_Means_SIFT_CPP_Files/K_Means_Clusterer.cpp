#include "K_Means_Clusterer.hpp"

K_Means_Clusterer::K_Means_Clusterer() {}

void K_Means_Clusterer::generate_clusters(std::vector<Cluster>* clusters,
	                                      std::vector<Image>* images,
	                                      int num_clusters)
{
	clusters->clear();
	std::vector<int> used_indexes;
	for (int k = 0; k < num_clusters; k++)
	{
		int index = rand() % (int)images->size();
		while (std::find(used_indexes.begin(), used_indexes.end(), index) != used_indexes.end())
		{
			index = rand() % (int)images->size();
		}
		Cluster cluster = Cluster(&images->at(index));
		clusters->push_back(cluster);
		used_indexes.push_back(index);
	}
}

void K_Means_Clusterer::cluster_by_SIFT_features(std::vector<Cluster>* clusters,
	                                             std::vector<Image>* images,
	                                             int num_clusters,
	                                             int num_epochs,
	                                             int cluster_size_limit,
	                                             int max_penalties,
	                                             int timeout_duration) 
{
	this->generate_clusters(clusters, images, num_clusters);
	int epoch = 0;
	bool are_clusters_centered = false;
	while ((epoch < num_epochs) && (are_clusters_centered == false))
	{
		printf("Starting epoch %d...\n", epoch + 1);
		for (int i = 0; i < (int)clusters->size(); i++) { clusters->at(i).clear(); }
		Cluster* recently_used_cluster = 0;
		int num_full_clusters = 0;
		int num_clusters_in_timeout = 0;
		if (num_full_clusters < (int)clusters->size())
		{
			for (int j = 0; j < (int)images->size(); j++)
			{
				int max_weight = 0;
				int max_weight_index = 0;
				for (int k = 0; k < (int)clusters->size(); k++)
				{
					if ((clusters->at(k).get_is_full() == false) &&
						(clusters->at(k).get_is_in_timeout() == false))
					{
						Edge edge = Edge(clusters->at(k).get_centroid(), &images->at(j));
						if (edge.get_weight() > max_weight)
						{
							max_weight = edge.get_weight();
							max_weight_index = k;
						}
					}
				}
				clusters->at(max_weight_index).add(&images->at(j));
				std::cout << "Image " << images->at(j).get_name();
				std::cout << " has been assigned to cluster " << max_weight_index + 1;
				std::cout << ". Cluster " << max_weight_index + 1 << " now has ";
				std::cout << clusters->at(max_weight_index).size() << " items.\n";
				if (clusters->at(max_weight_index).size() == cluster_size_limit)
				{
					clusters->at(max_weight_index).set_is_full(true);
					printf("Cluster %d is now full.\n", max_weight_index + 1);
					num_full_clusters++;
				}
				for (int m = 0; m < (int)clusters->size(); m++)
				{
					if (clusters->at(m).get_is_in_timeout() == true)
					{
						clusters->at(m).decrement_timeout_duration();
						if (clusters->at(m).get_timeout_duration() == 0)
						{
							clusters->at(m).set_is_in_timeout(false);
							printf("Cluster %d is back in rotation.\n", m + 1);
							num_clusters_in_timeout--;
						}
					}
				}
				int unavailable_clusters = num_full_clusters + num_clusters_in_timeout;
				if (unavailable_clusters < ((int)clusters->size() - 1))
				{
					if (clusters->at(max_weight_index).get_is_full() == false)
					{
						if (recently_used_cluster != &clusters->at(max_weight_index))
						{
							clusters->at(max_weight_index).clear_penalties();
							recently_used_cluster = &clusters->at(max_weight_index);
						}
						clusters->at(max_weight_index).increment_penalties();
						if (clusters->at(max_weight_index).get_penalties() == max_penalties)
						{
							clusters->at(max_weight_index).clear_penalties();
							clusters->at(max_weight_index).set_timeout_duration(timeout_duration);
							clusters->at(max_weight_index).set_is_in_timeout(true);
							printf("Cluster %d has too many penalties. It has been placed in time out.\n",
								max_weight_index + 1);
							num_clusters_in_timeout++;
						}
					}
				}
			}
		}
		std::cout << "Image assignment complete. Calculating means...\n";
		int centered_clusters = 0;
		for (int n = 0; n < (int)clusters->size(); n++)
		{
			clusters->at(n).calculate_mean();
			if (clusters->at(n).get_is_centroid_centered() == true) { centered_clusters++; }
		}
		std::cout << "Mean calculation complete.\n";
		std::cout << centered_clusters << "/" << (int)clusters->size() << " clusters are centered.\n";
		if (centered_clusters == (int)clusters->size())
		{
			are_clusters_centered = true;
			std::cout << "All clusters are centered. Clustering complete.\n";
		}
		else if ((epoch + 1) == num_epochs)
		{
			printf("Finished epoch %d. Reached desired number of epochs. Clustering complete.\n",
				    epoch + 1);
		}
		else { printf("Finished epoch %d.\n", epoch + 1); }
		epoch++;
	}
}
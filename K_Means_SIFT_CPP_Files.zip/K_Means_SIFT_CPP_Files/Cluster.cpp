#include "Cluster.hpp"

Cluster::Cluster(Image* centroid)
{
	this->centroid = centroid;
	this->edges = {};
	this->penalties = 0;
	this->timeout_duration = 0;
	this->is_centroid_centered = false;
	this->is_in_timeout = false;
	this->is_full = false;
}

Image* Cluster::get_centroid() { return this->centroid; }

std::vector<Image*>* Cluster::get_images() { return &this->images; }

int Cluster::get_penalties() { return this->penalties; }

int Cluster::get_timeout_duration() { return this->timeout_duration; }

int Cluster::size() { return (int)this->images.size(); }

bool Cluster::get_is_centroid_centered() { return this->is_centroid_centered; }

bool Cluster::get_is_in_timeout() { return this->is_in_timeout; }

bool Cluster::get_is_full() { return this->is_full; }

void Cluster::set_is_in_timeout(bool is_in_timeout) { this->is_in_timeout = is_in_timeout; }

void Cluster::set_is_full(bool is_full) { this->is_full = is_full; }

void Cluster::calculate_mean()
{
	if ((int)this->images.size() > 0)
	{
		std::vector<Image*> images_left_of_centroid;
		std::vector<Image*> images_right_of_centroid;
		std::vector<Image*> sequenced_images;
		for (Edge edge : this->edges)
		{
			if (edge.get_image_sequence() == 1) { images_right_of_centroid.push_back(edge.get_image_2()); }
			else { images_left_of_centroid.push_back(edge.get_image_2()); }
		}
		for (Image* left_side_image : images_left_of_centroid)
		{
			sequenced_images.push_back(left_side_image);
		}
		for (Image* right_side_image : images_right_of_centroid)
		{
			sequenced_images.push_back(right_side_image);
		}
		int midpoint = (int)floor((int)this->images.size() / 2);
		Image* center_image = this->images[midpoint];
		if (this->centroid == center_image) { this->is_centroid_centered = true; }
		else
		{
			this->is_centroid_centered = false;
			this->centroid = center_image;
		}
	}
	else { this->is_centroid_centered = true; }
}

void Cluster::increment_penalties() { this->penalties++; }

void Cluster::clear_penalties() { this->penalties = 0; }

void Cluster::set_timeout_duration(int timeout_duration) { this->timeout_duration = timeout_duration; }

void Cluster::decrement_timeout_duration() { this->timeout_duration--;}

void Cluster::clear()
{
	this->images.clear();
	this->edges.clear();
	this->penalties = 0;
	this->timeout_duration = 0;
	this->is_centroid_centered = false;
	this->is_in_timeout = false;
	this->is_full = false;
}

void Cluster::add(Image* image)
{
	this->images.push_back(image);
	Edge edge = Edge(this->centroid, image);
	this->edges.push_back(edge);
}

void Cluster::save(std::filesystem::path path)
{
	char image_dir_buffer[300];
	for (Image* image : this->images)
	{
		sprintf_s(image_dir_buffer, "%s\\%s", path.string().c_str(), image->get_name().c_str());
		cv::imwrite(image_dir_buffer, *image->get_pixels());
	}
}
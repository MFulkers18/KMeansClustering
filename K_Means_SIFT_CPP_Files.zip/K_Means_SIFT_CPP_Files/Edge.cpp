#include "Edge.hpp"

Edge::Edge(Image* image_1, Image* image_2)
{
	this->image_1 = image_1;
	this->image_2 = image_2;
	cv::Ptr<cv::BFMatcher> matcher = cv::BFMatcher::create(cv::NORM_L2, true);
	matcher->match(*this->image_1->get_descriptors(),
		           *this->image_2->get_descriptors(), 
		            this->matching_features);
	this->weight = (int)this->matching_features.size();
	this->image_sequence = this->find_image_sequence(&this->matching_features, 
		                                             this->image_1, 
		                                             this->image_2);
}

int Edge::find_image_sequence(std::vector<cv::DMatch>* matches, Image* query_image, Image* train_image)
{
	int votes_query_image_right = 0;
	int votes_query_image_left = 0;
	int image_sequence = 0; // 0 if query image is on the right, 1 if it's on the left.
	for (cv::DMatch match : *matches)
	{
		float query_image_x_coordinate = query_image->get_keypoints()->at(match.queryIdx).pt.x;
		float train_image_x_coordinate = train_image->get_keypoints()->at(match.trainIdx).pt.x;
		if (query_image_x_coordinate < train_image_x_coordinate) { votes_query_image_right++; }
		else if (query_image_x_coordinate > train_image_x_coordinate) { votes_query_image_left++; }
	}
	if (votes_query_image_left > votes_query_image_right) { image_sequence = 1; }
	return image_sequence;
}

Image* Edge::get_image_1() { return this->image_1; }

Image* Edge::get_image_2() { return this->image_2; }

int Edge::get_weight() { return this->weight; }

int Edge::get_image_sequence() { return this->image_sequence; }
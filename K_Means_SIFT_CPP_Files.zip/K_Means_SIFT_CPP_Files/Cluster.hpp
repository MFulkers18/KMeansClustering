#ifndef CLUSTER_HPP
#define CLUSTER_HPP
#include "Edge.hpp"
#include <filesystem>
#include <opencv2/highgui.hpp>

class Cluster
{
	private:
		Image* centroid;
		std::vector<Image*> images;
		std::vector<Edge> edges;
		int penalties;
		int timeout_duration;
		bool is_centroid_centered;
		bool is_in_timeout;
		bool is_full;
	public:
		Cluster(Image* centroid);
		Image* get_centroid();
		std::vector<Image*>* get_images();
		int get_penalties();
		int get_timeout_duration();
		int size();
		bool get_is_centroid_centered();
		bool get_is_in_timeout();
		bool get_is_full();
		void set_is_in_timeout(bool is_in_timeout);
		void set_is_full(bool is_full);
		void calculate_mean();
		void increment_penalties();
		void clear_penalties();
		void set_timeout_duration(int timeout_duration);
		void decrement_timeout_duration();
		void clear();
		void add(Image* image);
		void save(std::filesystem::path path);
};
#endif // CLUSTER_HPP
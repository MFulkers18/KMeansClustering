#ifndef EDGE_HPP
#define EDGE_HPP
#include "Image.hpp"

class Edge
{
	private:
		Image* image_1;
		Image* image_2;
		std::vector<cv::DMatch> matching_features;
		int weight; // number of matching features
		int image_sequence;
		int find_image_sequence(std::vector<cv::DMatch>* matches, Image* query_image, Image* train_image);
	public:
		Edge(Image* image_1, Image* image_2);
		Image* get_image_1();
		Image* get_image_2();
		int get_weight();
		int get_image_sequence();
};
#endif // EDGE_HPP
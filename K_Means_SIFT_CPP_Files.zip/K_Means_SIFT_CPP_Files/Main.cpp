#include "K_Means_Clusterer.hpp"
#include <opencv2/imgproc.hpp>

int main()
{
	std::filesystem::path images_path = "C:\\Users\\fca_m\\OneDrive\\Pictures\\Library";
	std::vector<cv::Mat> descriptors_array;
	std::vector<Image> images;
	for (auto& pointer : std::filesystem::directory_iterator(images_path))
	{
		std::string filepath = pointer.path().string();
		std::string image_name = pointer.path().filename().string();
		cv::Mat pixels = cv::imread(filepath);
		cv::resize(pixels, pixels, pixels.size() * 0, .1, .1, cv::INTER_AREA);
		Image image = Image(pixels, image_name);
		images.push_back(image);
		std::cout << "Image " << image_name << " processed.\n";
	}
	K_Means_Clusterer k_means_clusterer = K_Means_Clusterer();
	std::vector<Cluster> clusters;
	int num_clusters = 10;
	int num_epochs = 20;
	int cluster_size_limit = 11;
	int max_penalties = (int)INFINITY;
	int timeout_duration = (int)INFINITY;
	k_means_clusterer.cluster_by_SIFT_features(&clusters,
		                                       &images,
		                                       num_clusters,
											   num_epochs,
		                                       cluster_size_limit,
		                                       max_penalties,
		                                       timeout_duration);
	std::cout << "Cluster sizes: ";
	for (Cluster cluster : clusters) { printf("%d images ", cluster.size()); }
	std::cout << std::endl;
	std::filesystem::path main_dir = "C:\\Clustering_Results";
	if (std::filesystem::create_directory(main_dir) == 1)
	{
		std::cout << "Main directory created.\n";
	}
	else { std::cout << "Directory already exists.\n"; }
	std::filesystem::path SIFT_clustering_dir = main_dir /= "SIFT_Clustering";
	if (std::filesystem::create_directory(SIFT_clustering_dir) == 1)
	{
		std::cout << "Directory created.\n";
	}
	else { std::cout << "Directory already exists.\n"; }
	char clustering_settings_buffer[200];
	sprintf_s(clustering_settings_buffer,
		      "%d_Clusters_%d_Epochs_%d_Cluster_Size_Limit_%d_Penalties_%d_Timeouts",
		      num_clusters, num_epochs, cluster_size_limit, max_penalties, timeout_duration);
	std::filesystem::path experiment_dir = SIFT_clustering_dir /= clustering_settings_buffer;
	if (std::filesystem::create_directory(experiment_dir) == 1)
	{
		std::cout << "Successfully created experiment directory.\n";
	}
	for (int i = 0; i < (int)clusters.size(); i++)
	{
		char cluster_buffer[250];
		sprintf_s(cluster_buffer, "%s\\Cluster_%d",experiment_dir.string().c_str(),  i+1);
		std::filesystem::path cluster_dir = cluster_buffer;
		if (std::filesystem::create_directory(cluster_dir) == 1)
		{
			clusters[i].save(cluster_dir);
			std::cout << "Cluster: " << i << " saved to " << cluster_buffer << std::endl;
		}
	}
	std::cout << "Open " << experiment_dir.string() << " to view clustering results.\n";
	
	return 0;
}
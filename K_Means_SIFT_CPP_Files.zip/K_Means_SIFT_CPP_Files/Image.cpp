#include "Image.hpp"

Image::Image(cv::Mat pixels, std::string name)
{
	this->pixels = pixels;
	cv::Ptr<cv::SIFT> sift = cv::SIFT::create();
	sift->detect(this->pixels, this->keypoints);
	sift->compute(this->pixels, this->keypoints, this->descriptors);
	this->name = name;
}

cv::Mat* Image::get_pixels() { return &this->pixels; }

std::vector<cv::KeyPoint>* Image::get_keypoints() { return &this->keypoints; }

cv::Mat* Image::get_descriptors() { return &this->descriptors; }

std::string Image::get_name() { return this->name; }